class Bola
{
	constructor(novaImagem, novoX, novoY)
	{
		this.imagem = new Image();
		this.imagem.src = novaImagem;		
		this.velocidadeY = -10;
		this.x = novoX;
		this.y = novoY;
		this.ConfigInicial( novoY);
	}
	
	ConfigInicial( novoY)
	{
		
		this.y = novoY;
	}
	
	Desenhar()
	{
		contexto.drawImage(this.imagem, this.x, this.y);
	}
	
	Atualizar(jogador, blocos, pHUD, vHUD)
	{
		
		this.y = this.y + this.velocidadeY;
		
		this.TestandoColisaoBlocos(blocos, jogador, pHUD);		
			
	}
		
	
	
	
	TestandoColisaoBlocos(blocos, jogador, pHUD)
	{
		for (var i = 0; i < blocos.length; i++)
		{
			if (this.x < blocos[i].x + blocos[i].imagem.width &&
				this.x + this.imagem.width > blocos[i].x &&
				this.y < blocos[i].y + blocos[i].imagem.height &&
				this.y + this.imagem.height > blocos[i].y) 
			{
				blocos.splice(i, 1);
				jogador.pontos = jogador.pontos + 10;
				pHUD.texto = "Pontos: " + jogador.pontos;
				this.x = 1000;				
			}
		}
	}	
	
	
}