class Bloco
{
	constructor(novaImagem, novoX, novoY)
	{
		this.imagem = new Image();
		this.imagem.src = novaImagem;
		this.x = novoX;
		this.y = novoY;
	}
	
	Desenhar()
	{
		contexto.drawImage(this.imagem, this.x, this.y);
	}
}