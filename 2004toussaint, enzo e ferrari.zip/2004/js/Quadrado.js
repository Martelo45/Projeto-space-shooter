class Quadrado
{
	constructor(novaImagem, novoX, novoY)
	{
		this.imagem = new Image();
		this.imagem.src = novaImagem;
		this.x = novoX;
		this.y = novoY;
		this.velocidadeX = 5;
		this.velocidadeY = 2;
	}
	
	Desenhar()
	{
		contexto.drawImage(this.imagem, this.x, this.y);
	}
	
	Atualizar()
	{
		this.x = this.x + this.velocidadeX;
		this.y = this.y + this.velocidadeY;
		
		this.TestandoLimite();
	}
		
	TestandoLimite()
	{
		if(this.x + this.imagem.width > canvas.width ||
			this.x < 0)
		{
			var aleatorio = Math.random() * 750;		
			this.x = Math.floor (aleatorio);
			
			aleatorio = Math.random() * 550;		
			this.y = Math.floor (aleatorio);
			
			aleatorio = (Math.random() * 3) - 1;
			aleatorio = Math.floor (aleatorio);
			
			if(aleatorio != 0) 
			{
				this.velocidadeX *= aleatorio;
			}
		}
		
		if(this.y + this.imagem.height > canvas.height ||
			this.y < 0)
		{
			var aleatorio = Math.random() * 750;		
			this.x = Math.floor (aleatorio);
			
			aleatorio = Math.random() * 550;		
			this.y = Math.floor (aleatorio);
			
			aleatorio = (Math.random() * 3) - 1;
			aleatorio = Math.floor (aleatorio);
			
			if(aleatorio != 0) 
			{
				this.velocidadeY *= aleatorio;
			}
		}
	}
	
}