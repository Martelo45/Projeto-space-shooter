class Jogador
{
	constructor(novaImagem, novoX, novoY)
	{
		this.imagem = new Image();
		this.imagem.src = novaImagem;
		this.x = novoX;
		this.y = novoY;
		this.velocidade = 5;
		this.moveEsq = false;
		this.moveDir = false;
		this.pontos = 0;
		this.vidas = 3;

	}
	
	Desenhar()
	{
		contexto.drawImage(this.imagem, this.x, this.y, this.imagem.width, this.imagem.height);
	}
	
	Atualizar(bola)
	{		
		if(this.moveDir == true) 
		{
			this.x = this.x + this.velocidade;
		}
		
		if(this.moveEsq == true) 
		{
			this.x = this.x - this.velocidade;
		}
		
		this.TestandoLimite();
	}
	
	GerenciaTeclado(e, pressionado, bola)
	{		
		if(e.keyCode == 39) //seta p/ direita
		{
			if(pressionado == true)
			{
				this.moveDir = true;
			}
			else
			{
				this.moveDir = false;
			}
		}
		
		if(e.keyCode == 37) //seta p/ esquerda
		{
			if(pressionado == true)
			{
				this.moveEsq = true;
			}
			else
			{
				this.moveEsq = false;
			}
		}

		if(e.keyCode == 32 && bola.x == 1000 || e.keyCode == 32 && bola.y < 0)
		{
			bola.x = this.x + (this.imagem.width / 2) ;
			bola.y = this.y;
		}
	}
		
	TestandoLimite()
	{
		if(this.x + this.imagem.width > canvas.width)
		{
			this.x = this.x - this.velocidade;
		}
		
		if(this.x < 0)
		{
			this.x = this.x + this.velocidade;
		}
		if( this.pontos == 530){
			cena = 2;
		}
	}
	
}

