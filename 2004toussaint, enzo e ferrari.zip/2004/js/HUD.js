class HUD
{
	constructor(novoTexto, novoX, novoY, novaCor, novoTamanho, novaFonte)
	{
		this.texto = novoTexto;
		this.x = novoX;
		this.y = novoY;
		this.cor = novaCor;
		this.tamanho = novoTamanho;
		this.fonte = novaFonte;		
	}
	
	Desenhar()
	{
		contexto.fillStyle = this.cor;
		contexto.font = this.tamanho + " " + this.fonte;
		contexto.fillText(this.texto, this.x, this.y);
	}
}